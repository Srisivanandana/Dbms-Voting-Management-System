import { Routes, Route, Navigate } from 'react-router-dom';
import Registration from './Registration';
import LoginPage from './LoginPage';
import HomePage from './HomePage';
import VoteConfirmation from './VoteConfirmation';
import Results from './Results';
import './App.css';

function App() {
  return (
    <div className="app">
      <Routes>
        <Route path="/register" element={<Registration />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/home" element={<HomePage />} />
        <Route path="/vote-confirmation" element={<VoteConfirmation />} />
        <Route path="/results" element={<Results />} />
        <Route path="/" element={<Navigate to="/login" replace />} />
      </Routes>
    </div>
  );
}

export default App;
