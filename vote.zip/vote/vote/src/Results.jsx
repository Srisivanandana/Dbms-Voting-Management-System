import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './Results.css';

const Results = () => {
  const navigate = useNavigate();
  const [winner, setWinner] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const resultsDate = new Date('2025-04-24').toLocaleDateString();

  useEffect(() => {
    const fetchWinner = async () => {
      try {
        const response = await fetch('http://10.21.76.156:5050/voters_list');
        if (!response.ok) {
          throw new Error('Failed to fetch results');
        }
        const data = await response.json();
        setWinner(data.winner);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchWinner();
  }, []);

  const handleReturnHome = () => {
    try {
      navigate('/home');
    } catch (err) {
      console.error('Navigation error:', err);
      // Fallback to window.location if navigation fails
      window.location.href = '/home';
    }
  };

  if (loading) {
    return (
      <div className="login-container">
        <div className="right-panel">
          <div className="form-container">
            <h2 className="form-title">Loading Results...</h2>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="login-container">
        <div className="right-panel">
          <div className="form-container">
            <h2 className="form-title">Error</h2>
            <p className="error-message">{error}</p>
            <button 
              className="login-btn"
              onClick={handleReturnHome}
            >
              Return to Home
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="login-container">
      <div className="left-panel">
        <div className="logo-container">
          <h1>
            <span className="logo-box">V</span>OTE
          </h1>
          <h2>Election Results</h2>
          <p className="tagline">Official Results Published</p>
        </div>
      </div>

      <div className="right-panel">
        <div className="form-container">
          <h2 className="form-title">Election Results 2024</h2>
          <p className="greeting">Results published on {resultsDate}</p>
          
          <div className="winner-container">
            <div className="winner-card">
              <div className="crown-icon">👑</div>
              <h3 className="winner-title">Winner</h3>
              <h2 className="winner-name">{winner?.name || 'No winner declared'}</h2>
              <p className="winner-department">{winner?.department || ''}</p>
            </div>
          </div>

          <button 
            className="login-btn"
            onClick={handleReturnHome}
          >
            Return to Home
          </button>
        </div>
      </div>
    </div>
  );
};

export default Results; 