import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import './VoteConfirmation.css';

const VoteConfirmation = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { candidate } = location.state || {};
  const timestamp = new Date().toLocaleString();

  const handleReturnHome = () => {
    // Keep the voted state in localStorage
    navigate('/home');
  };

  return (
    <div className="login-container">
      <div className="left-panel">
        <div className="logo-container">
          <h1>
            <span className="logo-box">V</span>OTE
          </h1>
          <h2>Vote Confirmation</h2>
          <p className="tagline">Your vote has been recorded</p>
        </div>
      </div>

      <div className="right-panel">
        <div className="form-container">
          <div className="header">
            <h2 className="form-title">Vote Confirmation</h2>
            <p className="greeting">Thank you for participating in the election</p>
          </div>
          
          <div className="confirmation-details">
            <div className="detail-item">
              <h4>✅ Vote Cast Successfully</h4>
              <p>Your vote has been recorded in the system.</p>
            </div>

            <div className="detail-item">
              <h4>👤 Candidate</h4>
              <p>{candidate?.name}</p>
              <p className="sub-text">{candidate?.department}</p>
            </div>

            <div className="detail-item">
              <h4>⏰ Timestamp</h4>
              <p>{timestamp}</p>
            </div>

            <div className="detail-item">
              <h4>📝 Transaction ID</h4>
              <p>{Math.random().toString(36).substring(2, 15)}</p>
            </div>

            <div className="detail-item">
              <h4>📢 Results Announcement</h4>
              <p>Results will be announced on April 24, 2025</p>
              <p className="sub-text">Stay tuned for the election results!</p>
            </div>
          </div>

          <button 
            className="login-btn"
            onClick={handleReturnHome}
          >
            Return to Home
          </button>
        </div>
      </div>
    </div>
  );
};

export default VoteConfirmation; 