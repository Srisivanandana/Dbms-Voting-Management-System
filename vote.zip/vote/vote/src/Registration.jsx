import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import "./Registration.css";

const Registration = () => {
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        user_name: '',
        pass_word: '',
        confirm_password: '',
        email: '',
        department: '',
        batch: ''
    });
    const [errors, setErrors] = useState({});
    const [isLoading, setIsLoading] = useState(false);
    const [errorMessage, setErrorMessage] = useState('');

    const validateForm = () => {
        const newErrors = {};
        
        // Username validation
        if (!formData.user_name.trim()) {
            newErrors.user_name = 'Username is required';
        } else if (formData.user_name.length < 3) {
            newErrors.user_name = 'Username must be at least 3 characters';
        }

        // Password validation
        if (!formData.pass_word) {
            newErrors.pass_word = 'Password is required';
        } else if (formData.pass_word.length < 6) {
            newErrors.pass_word = 'Password must be at least 6 characters';
        }

        // Confirm password validation
        if (formData.pass_word !== formData.confirm_password) {
            newErrors.confirm_password = 'Passwords do not match';
        }

        // Email validation
        if (!formData.email) {
            newErrors.email = 'Email is required';
        } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
            newErrors.email = 'Email is invalid';
        }

        // Department validation
        if (!formData.department) {
            newErrors.department = 'Department is required';
        }

        // Batch validation
        if (!formData.batch) {
            newErrors.batch = 'Batch is required';
        }

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: value
        }));
        // Clear error when user starts typing
        if (errors[name]) {
            setErrors(prev => ({
                ...prev,
                [name]: ''
            }));
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setErrorMessage('');

        if (!validateForm()) {
            return;
        }

        setIsLoading(true);
        try {
            const response = await fetch('http://localhost:5050/register/user_credentials', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    user_name: formData.user_name,
                    pass_word: formData.pass_word,
                    email: formData.email,
                    department: formData.department,
                    batch: formData.batch
                })
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || 'Registration failed');
            }

            if (data.success) {
                navigate('/login');
            } else {
                setErrorMessage(data.message || 'Registration failed');
            }
        } catch (err) {
            setErrorMessage(err.message || 'An error occurred during registration');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="login-container">
            <div className="left-panel">
                <div className="logo-container">
                    <h1>
                        <span className="logo-box">V</span>OTE
                    </h1>
                    <h2>Create Your Account</h2>
                    <p className="tagline">Join the voting community</p>
                </div>
            </div>

            <div className="right-panel">
                <div className="form-container">
                    <h2 className="form-title">Sign Up</h2>
                    <p className="greeting">Create your account to participate in elections</p>
                    
                    {errorMessage && (
                        <div className="error-message">
                            {errorMessage}
                        </div>
                    )}

                    <form onSubmit={handleSubmit}>
                        <div className="input-group">
                            <label htmlFor="user_name">Username</label>
                            <input
                                type="text"
                                id="user_name"
                                name="user_name"
                                value={formData.user_name}
                                onChange={handleChange}
                                className={errors.user_name ? 'error' : ''}
                                placeholder="Enter your username"
                            />
                            {errors.user_name && (
                                <span className="error-text">{errors.user_name}</span>
                            )}
                        </div>

                        <div className="input-group">
                            <label htmlFor="email">Email</label>
                            <input
                                type="email"
                                id="email"
                                name="email"
                                value={formData.email}
                                onChange={handleChange}
                                className={errors.email ? 'error' : ''}
                                placeholder="Enter your email"
                            />
                            {errors.email && (
                                <span className="error-text">{errors.email}</span>
                            )}
                        </div>

                        <div className="input-group">
                            <label htmlFor="department">Department</label>
                            <input
                                type="text"
                                id="department"
                                name="department"
                                value={formData.department}
                                onChange={handleChange}
                                className={errors.department ? 'error' : ''}
                                placeholder="Enter your department"
                            />
                            {errors.department && (
                                <span className="error-text">{errors.department}</span>
                            )}
                        </div>

                        <div className="input-group">
                            <label htmlFor="batch">Batch</label>
                            <input
                                type="text"
                                id="batch"
                                name="batch"
                                value={formData.batch}
                                onChange={handleChange}
                                className={errors.batch ? 'error' : ''}
                                placeholder="Enter your batch"
                            />
                            {errors.batch && (
                                <span className="error-text">{errors.batch}</span>
                            )}
                        </div>

                        <div className="input-group">
                            <label htmlFor="pass_word">Password</label>
                            <input
                                type="password"
                                id="pass_word"
                                name="pass_word"
                                value={formData.pass_word}
                                onChange={handleChange}
                                className={errors.pass_word ? 'error' : ''}
                                placeholder="Enter your password"
                            />
                            {errors.pass_word && (
                                <span className="error-text">{errors.pass_word}</span>
                            )}
                        </div>

                        <div className="input-group">
                            <label htmlFor="confirm_password">Confirm Password</label>
                            <input
                                type="password"
                                id="confirm_password"
                                name="confirm_password"
                                value={formData.confirm_password}
                                onChange={handleChange}
                                className={errors.confirm_password ? 'error' : ''}
                                placeholder="Confirm your password"
                            />
                            {errors.confirm_password && (
                                <span className="error-text">{errors.confirm_password}</span>
                            )}
                        </div>

                        <button 
                            type="submit" 
                            className="login-btn"
                            disabled={isLoading}
                        >
                            {isLoading ? 'Creating Account...' : 'Create Account'}
                        </button>
                    </form>

                    <p className="login-link">
                        Already have an account?{' '}
                        <span onClick={() => navigate('/login')}>
                            Login here
                        </span>
                    </p>
                </div>
            </div>
        </div>
    );
};

export default Registration;
